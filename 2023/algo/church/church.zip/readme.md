# Church
### Author: skittles1412

[Install rust](https://rustup.rs/), then `cargo doc --open`, or read the doc comments in src/lib.rs.

IO related code in src/main.rs, or just use the template provided at src/bin/solve.rs.

Remember to worship Warry.
