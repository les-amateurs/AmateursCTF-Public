# simpleOS

To build locally, run `sudo make build`. This will generate a `disk.img` file that can be run in qemu. Use `run-local.sh` to test solves
locally as there will be a long pow on the server.